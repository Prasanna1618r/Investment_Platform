package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.repo.UserRepo;
import com.example.demo.service.UserServ;


@CrossOrigin
@RestController
public class UserController {
	@Autowired  
	private  UserRepo serviceRepository; 
	@Autowired
	private	UserServ service;

	@GetMapping("/get")
	 List<User> getList(){
		return serviceRepository.findAll();
	}
	@PostMapping("/post")
	public User create(@RequestBody User stu) {
		  return serviceRepository.save(stu);
	}
	@GetMapping("/get/{email}")
	public Optional<User> getbyid(@PathVariable String email){
		return service.getDetails(email);
	}
}
